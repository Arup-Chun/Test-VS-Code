"""
This package contains default serializers. You can override the
serialization process of a particular type as follows:

``jsons.set_serializer(custom_serializer, SomeClass)``
"""
